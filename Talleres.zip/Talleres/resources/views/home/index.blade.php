@extends('layouts.app')
@section('title', 'Home Page - Online Rocket Store')
@section('content')
<div class="text-center">
  <h2 class="overlay-text">Welcome to the application</h2>
</div>
@endsection
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet" />
<div class="mt-5">
    <?php if($errors->any()): ?>
    <div class="col-12">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(session()->has('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
</div>
<div class="container">
    <h1><?php echo e($viewData["title"]); ?></h1>
    <ul class="user-list">
        <?php $__currentLoopData = $viewData["users"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="user-item">
            <?php echo e($user->name); ?> - <?php echo e($user->email); ?>

            <a href="<?php echo e(route('user.profileindex', ['id' => $user->id])); ?>" class="btn btn-primary">Ver Cuenta</a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Talleres\resources\views/user/show.blade.php ENDPATH**/ ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet" />
<div class="container">
    <h1>User Details - <?php echo e($user->name); ?></h1>
    <div class="user-details">
        <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
        <p><strong>Budget:</strong></p>
        <form action="<?php echo e(route('user.delete', ['id' => $user->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Eliminar Cuenta</button>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Talleres\resources\views/user/profileindex.blade.php ENDPATH**/ ?>

<link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet" />
<div class="container">
    <h1>User Details - <?php echo e($user->name); ?></h1>
    <div class="user-details">
        <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
        <!-- Agrega más detalles según sea necesario -->
    </div>
</div>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Talleres\resources\views/user/show-details.blade.php ENDPATH**/ ?>
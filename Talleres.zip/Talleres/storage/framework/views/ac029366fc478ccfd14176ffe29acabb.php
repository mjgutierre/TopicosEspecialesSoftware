<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
  <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet" />
  <title><?php echo $__env->yieldContent('title', 'Online Rocket Store'); ?></title>
</head>

<body>
  <!-- header -->
  <header class="masthead bg-primary text-white text-center py-3">
    <div class="container d-flex align-items-center flex-column">
      <h2><?php echo $__env->yieldContent('subtitle', 'Rocket Store'); ?></h2>
    </div>
  </header>
  <!-- header -->

  <div class="container h-100">
    <div class="mt-5">
      <?php if($errors->any()): ?>
      <div class="col-12">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php endif; ?>

      <?php if(session()->has('error')): ?>
      <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
      <?php endif; ?>

      <?php if(session()->has('success')): ?>
      <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
    </div>

    <div class="container my-5 content-container">
      <div class="overlay"></div>
      <?php echo $__env->yieldContent('content'); ?>
    </div>


    <!-- footer -->
    <div class="copyright py-3 text-center text-white">
      <div class="container">
        <small>
          Copyright - <a class="text-reset fw-bold text-decoration-none" target="_blank" href="https://github.com/mjgutierre">
            Maria Jose Gutierrez Estrada
          </a>
        </small>
      </div>
    </div>
    <!-- footer -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous">
    </script> -->
</body>

</html><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Talleres\resources\views/layouts/app.blade.php ENDPATH**/ ?>
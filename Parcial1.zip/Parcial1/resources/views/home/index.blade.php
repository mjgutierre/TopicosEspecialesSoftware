@extends('layouts.app')
@section('title', 'Home Page - Online Animal Register')
@section('content')
<div class="text-center">
  <h2 class="overlay-text">Welcome to the application</h2>
</div>
@endsection
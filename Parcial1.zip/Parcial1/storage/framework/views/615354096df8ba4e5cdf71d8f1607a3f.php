
<?php $__env->startSection('title', 'Home Page - Online Animal Register'); ?>
<?php $__env->startSection('content'); ?>
<div class="text-center">
  <h2 class="overlay-text">Welcome to the application</h2>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Parcial1\resources\views/home/index.blade.php ENDPATH**/ ?>
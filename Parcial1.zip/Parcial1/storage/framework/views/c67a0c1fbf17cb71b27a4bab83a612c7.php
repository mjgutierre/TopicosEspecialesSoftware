<!-- ordenadar por puntaje / los de menor puntaje que aparezca de primero -->

<?php $__env->startSection('title', $viewData["title"]); ?>
<?php $__env->startSection('subtitle', $viewData["subtitle"]); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="custom-title">Listado de Animales</h1>
    <div class="row">
        <?php $__currentLoopData = $viewData['animals']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">
                        <?php if($animal->getType() === 'gato'): ?>
                            <span style="color: blue;"><?php echo e($animal->getName()); ?></span>
                        <?php else: ?>
                            <?php echo e($animal->getName()); ?>

                        <?php endif; ?>
                    </h5>
                    <p class="card-text">Id: <?php echo e($animal->getId()); ?></p>
                    <p class="card-text">Edad: <?php echo e($animal->getAge()); ?></p>
                    <p class="card-text">Tipo: <?php echo e($animal->getType()); ?></p>
                    <p class="card-text">Puntaje: <?php echo e($animal->getReview()); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Parcial1\resources\views/animal/list.blade.php ENDPATH**/ ?>
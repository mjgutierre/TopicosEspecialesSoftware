<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous" />
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet" />
    <title><?php echo $__env->yieldContent('title', 'Online Animal Register'); ?></title>
</head>

<body>
    <!-- header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-secondary py-3">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home.index')); ?>">Inicio</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ms-auto  ml-auto">
                    <a class="nav-link active" href="<?php echo e(route('animal.create')); ?>">Crear</a>
                    <a class="nav-link active" href="<?php echo e(route('animal.list')); ?>">Listar</a>
                    <a class="nav-link active" href="<?php echo e(route('animal.statistics')); ?>">Estadisticas</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- header -->

    <div class="container h-100">
        <div class="mt-5">
            <?php if($errors->any()): ?>
            <div class="col-12">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php if(session()->has('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if(session()->has('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
        </div>

        <div class="container my-5 content-container">
            <div class="overlay"></div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- footer -->
        <div class="copyright py-3 text-center text-white">
            <div class="container">
                <small>
                    Copyright - <a class="text-reset fw-bold text-decoration-none" target="_blank" href="https://github.com/mjgutierre">
                        Maria Jose Gutierrez Estrada
                    </a>
                </small>
            </div>
        </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Parcial1\resources\views/layouts/app.blade.php ENDPATH**/ ?>
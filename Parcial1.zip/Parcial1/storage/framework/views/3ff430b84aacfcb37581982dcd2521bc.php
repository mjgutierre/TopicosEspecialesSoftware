
<?php $__env->startSection('title', $viewData["title"]); ?>
<?php $__env->startSection('subtitle', $viewData["subtitle"]); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="custom-title">Listado de Estadisticas</h1>
        <div class="card-body">
            <div class="mt-4">
                <p class="custom-text">Cantidad de Mascotas Registradas:</p>
                <?php $__currentLoopData = $viewData['animalCount']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="custom-text"><?php echo e($count); ?> <?php echo e($type); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <p class="custom-text-avrg">Puntaje Promedio de Todas las Mascotas: <?php echo e(number_format($viewData['promedioReview'], 2)); ?></p>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelTutorials\Parcial1\resources\views/animal/statistics.blade.php ENDPATH**/ ?>